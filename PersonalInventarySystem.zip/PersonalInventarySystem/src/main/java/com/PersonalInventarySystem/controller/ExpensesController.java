package com.PersonalInventarySystem.controller;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.PersonalInventorySystem.bean.ExpensesBean;
import com.PersonalInventorySystem.dao.ExpensesDAO;

/**
 * Servlet implementation class ExpensesController
 */
public class ExpensesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExpensesController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out=response.getWriter();	
		out.println("<form>");
		out.println("<h1>Expenses  </h1> <br>");			
		out.println("<table>");	
				
		out.println(" <tr>");
		out.println(" <th>Expenses </th>");
		out.println(" <th><input type='text' name='expenses' placeholder='bill/ticket/stationary'></th>");
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th>Category </th>");
		out.println(" <th>");
		out.println("<select name='category' style='width:150px'>");
		out.println("<optgroup lable='select' name='category'>");
		out.println("<option value='home '>home</option>");
		out.println("<option value='home applience'>home applience</option>");
		out.println("</optgroup>");	
		out.println("</select>");	
		out.println("</th>");	
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th>Amount </th>");
		out.println(" <th><input type='number' name='amount'></th>");
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th>PayBy </th>");
		out.println(" <th>");
		out.println("<select name='payby' style='width:150px'>");
		out.println("<optgroup lable='select' name='payby'>");
		out.println("<option value='cash'>cash</option>");
		out.println("<option value='check'>check</option>");
		out.println("</optgroup>");	
		out.println("</select>");	
		out.println("</th>");	
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th>Date </th>");
		out.println(" <th><input type='date' name='date' placeholder='yyyy-mm-dd'></th>");
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th>Remark </th>");
		out.println(" <th><input type='text' name='remark'></th>");
		out.println(" </tr>"); 
		
		out.println(" <tr>");
		out.println(" <th><input type='submit' value='Add Expenses'></th>");
		out.println(" </tr>"); 
		
		out.println("</table>");
		out.println("</form>");
		
		
		String account=request.getParameter("expenses");
		double amount=Double.parseDouble(request.getParameter("amount"));
		String date=request.getParameter("date");
		String payby=request.getParameter("payby");
		String remark=request.getParameter("remark");
		
		ExpensesBean b=new ExpensesBean();
		HttpSession h=request.getSession();
		int userid=(Integer)h.getAttribute("userid");
		
		String s="";
		if(s!=account && s!=date && s!=payby && s!=remark) {
		b.setAmount(amount);
        b.setTransaction_date(date);
        b.setPayby(payby);
        b.setRemark(remark);
        b.setExp_ac(account);
        b.setUserid(userid);
        b.setExp_catid(userid);		
		int x= new ExpensesDAO().addEmployee(b);
		if(x>0) out.print("<h1>our data inserted successfully</h1>");
		  else   out.print("<h1>our data not successfully</h1>");
		}else   out.print("<h1>our data not successfully</h1>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
