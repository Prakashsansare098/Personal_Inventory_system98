package com.PersonalInventarySystem.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.PersonalInventorySystem.bean.UsersBean;
import com.PersonalInventorySystem.dao.UsersDAO;
import com.PersonalInventorySystem.utility.ConnectionPool;

public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistrationController() {
        super();
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String address=request.getParameter("address");
		
		UsersBean b=new UsersBean();
		
	//	String findide="select userid from users where username ="+username+" and password="+password+"";	
		
		b.setAddress(address);
		b.setEmail(email);
		b.setMobile(phone);
		b.setName(name);
		b.setPassword(password);
		b.setUsername(username);		
		UsersDAO d=new UsersDAO();
		String s="";
		int count=0;
		if(s!=name && s!=address && s!=phone && s!=password && s!=username && s!=email)  {
			for(UsersBean b1:d.findAll()) {
				if(b1.getUsername().equals(b.getUsername()) && b.getPassword().equals(b1.getPassword()) ) { count++;break;}
			}
			if(count==0) {
		          int x=d.addEmployee(b);		
		          if(x>0) response.sendRedirect("login");
		          
		          else { out.println("<h1><font color='red' size='20px'>please register </font></h1>");	
		           request.getRequestDispatcher("Registration Form.html").include(request, response);}
			} 
			else {  out.println("<h1><font color='red' size='20px'> please enter unique password or username </font></h1>");
			       request.getRequestDispatcher("Registration Form.html").include(request, response);}
		} 
		else {
			 out.println("<h1><font color='red' size='20px'> please register all field </font></h1>");
			  //  response.sendRedirect("Registration Form.html");
			    RequestDispatcher rd=request.getRequestDispatcher("Registration Form.html");
			    rd.include(request, response);
		
		     }
		
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
