package com.PersonalInventarySystem.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class linkTableController
 */
public class linkTableController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public linkTableController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		     out.println("<style>");
				out.println(" #tablel{ border:2px dotted blue;padding:10px;background-color:black;}");
         		out.println(" a {text-decoration: none; font-size:20px; color:blue;} ");
				out.println("  a:hover {background-color:orange;border:1px black solid;}");
				out.println(" #master{background-color:red;} ");
	            out.println(" </style>");
	
		out.println("<table id='tablel'>");
		out.println(" <tr><th><h1 id='master'>Master</h1></th></tr>");
		out.println(" <tr><td>   <a href='expensesCategory' target='framename' >Expenses Category </a><br></td></tr>");
		out.println("<tr><td>    <a href=' incomeCategory' target='framename'  >Income Category</a><br></td></tr>");
	    out.println("<tr><td>   <a href='ExpensesController'  target='framename' >Expenses</a><br></td></tr>");
		out.println("<tr><td>   <a href='IncomeController'  target='framename' >Income</a><br></td></tr>");
		out.println("<tr><td>    <a href='CashBookController'  target='framename' >Cash Book</a><br></td></tr>");
		out.println("<tr><td>   <a href='BankBookController'   target='framename'>Bank Book</a><br></td></tr>");
		out.println(" <tr><td>  <a href='DayBookController'   target='framename' >Day Book</a><br></td></tr>");
		out.println(" <tr><td>   <a href='BalanceSheetController'  target=framename>Balance Sheet</a><br> </td></tr>");                    
		out.println(" </table>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
