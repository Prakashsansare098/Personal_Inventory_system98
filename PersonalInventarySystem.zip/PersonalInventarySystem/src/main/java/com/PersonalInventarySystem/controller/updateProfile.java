package com.PersonalInventarySystem.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.PersonalInventorySystem.bean.UsersBean;
import com.PersonalInventorySystem.dao.UsersDAO;

public class updateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	/*	
		PrintWriter out=response.getWriter();
		out.println("<style>");
		out.println("a {text-decoration: none; font-size:20px; color:blue;} ");
		out.println(" a:hover {background-color:orange;border:1px black solid;}");
		out.println(" #tablef{ border:2px dotted blue;padding:10px;background-color:black;}");
		out.println("</style>");
	   
		out.println(" <form > <table id='tablef'>"); 
		out.println("  <tr>");
		out.println("  <th> <font color='blue' size='20px'>       Personal</font>");
		out.println("  <th> <a href='homePageController' target='_parent' style='padding:5px '>Home</a> </th>");
		out.println(" <th> <a href='userProfile' target='_parent' style='padding:5px'>Profile</a> </th>");
		out.println("  <th><a href='updateProfile' target='_parent'style='padding:5px'>Update Profile</a></th>");               
		out.println("<th><a href='login' target='_parent'style='padding:5px'>Logout</a></th>");               
		out.println(" </tr>");
		out.println("  <tr>");
		out.println(" <th> <font color='orange' size='20p'>Inventory</font> <font color='green' size='20px'>System</font></th>");
		out.println(" </tr>");      
		out.println(" </table>");
		out.println("</form>");

		HttpSession h=request.getSession();
		String name=(String)h.getAttribute("name");
		int userid=(Integer)h.getAttribute("userid");		
		out.println("<h1>'"+name+"'</h1>");
		
		out.println("<h1>Master</h1>");
		out.println("<iframe src='linkTableController' height='280px' width='220px'></iframe>");
		out.println("<iframe src='if2udp' height='280px' width='500px'></iframe>");
		PrintWriter out=response.getWriter();
		UsersDAO d=new UsersDAO();
 */    
         UsersDAO d=new UsersDAO();
		PrintWriter out=response.getWriter();
		
		HttpSession h=request.getSession();
		int userid=(Integer)h.getAttribute("userid");		

		UsersBean b=d.findByEmpNo(userid);
	
		out.println("<form action='updateTable' method='post'>");
		out.println("<table>");
		out.println(" <tr>");
		out.println(" <th><h2>Update USER Profile</h2></th>");
		out.println(" <th></th>");
		out.println(" <th></th>");
		out.println(" </tr><br>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>Name</th>");
		out.println(" <td><input type='text' value='"+b.getName()+"'name='name'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>Username</th>");
		out.println(" <td><input type='text' value='"+b.getUsername()+"' name='username'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>Password</th>");
		out.println(" <td><input type='text' value='"+b.getPassword()+"'name='password'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>PhoneNo</th>");
		out.println(" <td><input type='text' value='"+b.getMobile()+"'name='phone'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>Email</th>");
		out.println(" <td><input type='text' value='"+b.getEmail()+"'name='email'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th>Address</th>");
		out.println(" <td><input type='text' value='"+b.getAddress()+"'name='address'></td>");
		out.println(" </tr>");  
		
		out.println(" <tr>");
		out.println(" <th></th>");
		out.println(" <th></th>");
		out.println(" <td><input type='submit' value='Update' target='_self'></td>");
		out.println(" </tr>"); 
			
		out.println("</table>");
		out.println("</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
